import XCTest
@testable import TVShowsTests

XCTMain([
    testCase(TVShowsTests.allTests),
])
